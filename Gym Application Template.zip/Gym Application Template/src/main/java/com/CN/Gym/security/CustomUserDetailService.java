package com.CN.Gym.security;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailService implements UserDetailsService {

	/*
	 1. Autowire the necessary dependencies and override the interface methods.
	 */

}
