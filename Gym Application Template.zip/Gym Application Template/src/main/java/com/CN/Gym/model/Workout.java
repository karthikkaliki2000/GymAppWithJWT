package com.CN.Gym.model;


import com.fasterxml.jackson.annotation.JsonBackReference;
import javax.persistence.*;

/*
    This is the entity class, complete this class by doing the following:
    a. Add the required annotations for making this class an entity.
    b. Add the required lombok annotations for getter, setter and constructors
 */
public class Workout {

    private Long id;
    private String workoutName;
    private String description;
    private String difficultyLevel;
    private int duration;

}
