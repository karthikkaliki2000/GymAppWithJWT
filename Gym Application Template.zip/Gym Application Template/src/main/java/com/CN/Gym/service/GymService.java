package com.CN.Gym.service;


import com.CN.Gym.model.Gym;
import java.util.List;

public class GymService {

    /*
        This is the service class for Gym, you need to complete the class by doing the following:
        a. Use appropriate annotations.
        b. Complete the methods given below.
        c. Autowire the necessary dependencies.
     */


    public List<Gym> getAllGyms() {

    }

    public Gym getGymById() {

    }

    public void deleteGymById() {

    }

    public void updateGym() {

    }

    public void createGym() {

    }

    public void addMember() {

    }

    public void deleteMember() {

    }
}
